"""Data collection and transparent stock research rules for the Streamlit app."""
from __future__ import annotations

from datetime import datetime, timezone
from html.parser import HTMLParser
from math import sqrt
import re
from statistics import mean, stdev
from typing import Any


def ticker_candidates(raw: str) -> list[str]:
    symbol = raw.strip().upper()
    if not re.fullmatch(r"[A-Z0-9.^-]{1,20}", symbol):
        raise ValueError("Enter a ticker such as TCS, RELIANCE.NS, AAPL, or MSFT.")
    return [symbol] if "." in symbol or symbol.startswith("^") else [symbol + ".NS", symbol]


def _number(value: Any) -> float | None:
    try:
        result = float(value)
        return result if result == result and abs(result) != float("inf") else None
    except (ValueError, TypeError):
        return None


def market_data(raw: str) -> dict[str, Any]:
    import yfinance as yf

    last_error: Exception | None = None
    for symbol in ticker_candidates(raw):
        try:
            ticker = yf.Ticker(symbol)
            history = ticker.history(period="1y", interval="1d", auto_adjust=True, raise_errors=True)
            closes = history["Close"].dropna()
            if len(closes) < 50:
                raise ValueError("At least 50 trading days of history are required.")
            values = [float(x) for x in closes]
            dates = [date.strftime("%Y-%m-%d") for date in closes.index]
            price = values[-1]
            returns = [values[i] / values[i - 1] - 1 for i in range(1, len(values)) if values[i - 1] > 0]
            volatility = stdev(returns) * sqrt(252) * 100 if len(returns) > 1 else None
            try:
                currency = str(ticker.fast_info.currency or ("INR" if symbol.endswith((".NS", ".BO")) else "USD"))
            except Exception:
                currency = "INR" if symbol.endswith((".NS", ".BO")) else "USD"
            return {
                "symbol": symbol,
                "ticker": ticker,
                "price": price,
                "currency": currency,
                "sma50": mean(values[-50:]),
                "sma200": mean(values[-200:]) if len(values) >= 200 else None,
                "return6m": (price / values[-126] - 1) * 100 if len(values) >= 126 else None,
                "return12m": (price / values[0] - 1) * 100 if values[0] > 0 else None,
                "volatility": volatility,
                "chart": list(zip(dates, values)),
                "last_price_date": dates[-1],
            }
        except Exception as exc:
            last_error = exc
    raise ValueError("No usable price history was found. Check the ticker and exchange suffix.") from last_error


class _Ratios(HTMLParser):
    """Extract only the public summary ratios; ignore other page tables."""
    def __init__(self) -> None:
        super().__init__()
        self.depth = 0
        self.li_depth = 0
        self.text: list[str] = []
        self.rows: list[str] = []
        self.title_depth = 0
        self.title: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attributes = dict(attrs)
        if tag == "ul" and attributes.get("id") == "top-ratios":
            self.depth = 1
        elif self.depth:
            self.depth += 1
        if self.depth and tag == "li" and not self.li_depth:
            self.li_depth = 1
            self.text = []
        elif self.li_depth and tag != "li":
            self.li_depth += 1
        if tag == "h1" and not self.title:
            self.title_depth = 1
        elif self.title_depth and tag != "h1":
            self.title_depth += 1

    def handle_endtag(self, tag: str) -> None:
        if self.li_depth:
            self.li_depth -= 1
            if not self.li_depth:
                self.rows.append(" ".join(" ".join(self.text).split()))
        if self.depth:
            self.depth -= 1
        if self.title_depth:
            self.title_depth -= 1

    def handle_data(self, data: str) -> None:
        if self.li_depth:
            self.text.append(data)
        if self.title_depth:
            self.title.append(data)


def screener_data(symbol: str, price: float) -> dict[str, Any]:
    import requests

    empty = {"pe": None, "pb": None, "roe": None, "roce": None, "market_cap": None, "url": None}
    if not symbol.endswith((".NS", ".BO")):
        return empty
    code = symbol.rsplit(".", 1)[0]
    url = f"https://www.screener.in/company/{code}/consolidated/"
    response = requests.get(url, timeout=10, headers={"User-Agent": "Mozilla/5.0 (compatible; StockResearch/1.0)"})
    response.raise_for_status()
    parser = _Ratios()
    parser.feed(response.text)
    if not parser.rows:
        raise ValueError("Screener summary ratios were not found.")

    def ratio(label: str) -> float | None:
        row = next((r for r in parser.rows if re.search(label, r, re.I)), "")
        suffix = re.sub(label, "", row, count=1, flags=re.I)
        found = re.search(r"-?[\d,]+(?:\.\d+)?", suffix)
        return _number(found.group().replace(",", "")) if found else None

    book = ratio(r"Book Value")
    return {
        "pe": ratio(r"Stock P/E"),
        "pb": price / book if book and book > 0 else None,
        "roe": ratio(r"\bROE\b"),
        "roce": ratio(r"\bROCE\b"),
        "market_cap": next((re.sub(r"Market Cap", "", r, count=1, flags=re.I).strip() for r in parser.rows if "Market Cap" in r), None),
        "url": url,
    }


def fundamental_data(market: dict[str, Any]) -> tuple[dict[str, Any], list[str]]:
    warnings: list[str] = []
    symbol = market["symbol"]
    info: dict[str, Any] = {}
    try:
        info = market["ticker"].info or {}
    except Exception:
        warnings.append("Yahoo company profile was unavailable.")
    try:
        screen = screener_data(symbol, market["price"])
        source = "Screener and Yahoo Finance" if screen["url"] else "Yahoo Finance"
    except Exception:
        screen = {"pe": None, "pb": None, "roe": None, "roce": None, "market_cap": None, "url": None}
        source = "Yahoo Finance"
        if symbol.endswith((".NS", ".BO")):
            warnings.append("Screener ratios were unavailable; Yahoo values were used where possible.")

    # Yahoo debtToEquity is expressed as a percentage: 20 means 0.20x.
    yahoo_debt = _number(info.get("debtToEquity"))
    market_cap = screen["market_cap"]
    if not market_cap and _number(info.get("marketCap")):
        market_cap = f'{_number(info["marketCap"]):,.0f} {market["currency"]}'
    return {
        "name": str(info.get("longName") or info.get("shortName") or symbol.rsplit(".", 1)[0]),
        "sector": info.get("sector"),
        "pe": screen["pe"] if screen["pe"] is not None else _number(info.get("trailingPE")),
        "pb": screen["pb"] if screen["pb"] is not None else _number(info.get("priceToBook")),
        "roe": screen["roe"] if screen["roe"] is not None else (_number(info.get("returnOnEquity")) * 100 if _number(info.get("returnOnEquity")) is not None else None),
        "debt_equity": yahoo_debt / 100 if yahoo_debt is not None else None,
        "roce": screen["roce"],
        "market_cap": market_cap,
        "url": screen["url"],
        "source": source,
    }, warnings


def news_data(name: str, symbol: str, api_key: str) -> list[dict[str, str]]:
    import requests

    if not api_key:
        raise ValueError("NewsData.io key is missing from Streamlit secrets.")
    term = re.sub(r"\b(Limited|Ltd\.?|Inc\.?|Corporation|Corp\.?|PLC)\b", "", name, flags=re.I).strip()
    if not term:
        term = symbol.split(".")[0]
    response = requests.get(
        "https://newsdata.io/api/1/latest",
        params={"apikey": api_key, "q": f'"{term}"', "language": "en"},
        timeout=12,
    )
    response.raise_for_status()
    payload = response.json()
    if payload.get("status") != "success":
        raise ValueError(str(payload.get("message") or "News provider returned an error."))
    articles = []
    for item in payload.get("results", [])[:8]:
        link = str(item.get("link") or "")
        title = str(item.get("title") or "").strip()
        if title and link.startswith(("https://", "http://")):
            articles.append({"title": title, "link": link, "source": str(item.get("source_name") or item.get("source_id") or "News source"), "date": str(item.get("pubDate") or "")})
    return articles


POSITIVE = re.compile(r"\b(growth|profit|record|gain|rally|strong|upgrade|beats?|rise|improv(?:e|ed)|expands?)\b", re.I)
NEGATIVE = re.compile(r"\b(fall|loss|fraud|probe|decline|weak|downgrade|misses|drop|concern|slump)\b", re.I)


def _view(checks: list[tuple[bool | None, str]], minimum: int) -> dict[str, Any]:
    available = [ok for ok, _ in checks if ok is not None]
    good = sum(ok is True for ok in available)
    if len(available) < minimum:
        label = "Unavailable"
    elif good / len(available) >= .75 and good >= 2:
        label = "Bullish"
    elif good / len(available) >= .4:
        label = "Neutral"
    else:
        label = "Bearish"
    return {"label": label, "score": f"{good}/{len(available)}" if available else "—", "reasons": [f"{'Unavailable' if ok is None else 'Pass' if ok else 'Concern'}: {reason}" for ok, reason in checks]}


def evaluate(m: dict[str, Any], f: dict[str, Any], articles: list[dict[str, str]], warnings: list[str] | None = None) -> dict[str, Any]:
    quant = _view([
        (m["price"] > m["sma50"] if m["sma50"] is not None else None, "Price above 50-day average"),
        (m["price"] > m["sma200"] if m["sma200"] is not None else None, "Price above 200-day average"),
        (m["return6m"] > 0 if m["return6m"] is not None else None, "Six-month return positive"),
        (m["return12m"] > 0 if m["return12m"] is not None else None, "One-year return positive"),
        (m["volatility"] < 30 if m["volatility"] is not None else None, "Annual volatility below 30%"),
    ], minimum=3)
    fundamental = _view([
        (0 < f["pe"] < 30 if f["pe"] is not None else None, "P/E below 30"),
        (0 < f["pb"] < 5 if f["pb"] is not None else None, "Price/book below 5"),
        (f["roe"] > 12 if f["roe"] is not None else None, "ROE above 12%"),
        (f["debt_equity"] < .2 if f["debt_equity"] is not None else None, "Debt/equity below 0.20x"),
    ], minimum=2)
    positive = sum(bool(POSITIVE.search(a["title"])) for a in articles)
    negative = sum(bool(NEGATIVE.search(a["title"])) for a in articles)
    news_label = "Unavailable" if not articles else "Positive" if positive > negative else "Negative" if negative > positive else "Neutral"
    news = {"label": news_label, "score": f"{positive} positive / {negative} negative" if articles else "—",
            "reasons": [f"{len(articles)} recent headlines reviewed", "Keyword sentiment is a weak signal and may miss context."] if articles else ["No relevant recent headlines were returned."]}
    available = [x for x in (quant["label"], fundamental["label"], news_label) if x != "Unavailable"]
    vote = sum(1 if x in ("Bullish", "Positive") else -1 if x in ("Bearish", "Negative") else 0 for x in available)
    label = "Insufficient evidence" if len(available) < 2 else "Strong Watch" if vote >= 2 else "Watch" if vote >= 0 else "Caution" if vote == -1 else "Avoid"
    risks = []
    if m["volatility"] is not None and m["volatility"] >= 30: risks.append("High historical price volatility")
    if f["pe"] is not None and f["pe"] >= 30: risks.append("Elevated P/E")
    if f["debt_equity"] is not None and f["debt_equity"] >= .2: risks.append("Leverage above the rule threshold")
    if news_label == "Negative": risks.append("Negative headline keywords")
    if fundamental["label"] == "Unavailable": risks.append("Limited financial ratios")
    if news_label == "Unavailable": risks.append("No current news signal")
    if not risks: risks.append("Monitor valuation, filings, and sector conditions")
    summary = (f"Quant is {quant['label'].lower()}, fundamentals are {fundamental['label'].lower()}, and news is {news_label.lower()}. "
               + ("Too few independent signals are available for a combined call." if len(available) < 2 else
                  "The available signals lean favorable." if vote >= 2 else
                  "The available signals are mixed." if vote >= 0 else
                  "The available signals lean cautious."))
    return {"agents": {"Quant": quant, "Fundamental": fundamental, "News": news},
            "verdict": {"label": label, "summary": summary, "risks": risks, "coverage": f"{len(available)} of 3 agents contributed."},
            "warnings": warnings or [], "checked_at": datetime.now(timezone.utc).isoformat()}
