"""Streamlit entrypoint: run with `streamlit run app.py`."""
from __future__ import annotations

import os
from datetime import datetime

import pandas as pd
import streamlit as st

from engine import evaluate, fundamental_data, market_data, news_data


st.set_page_config(page_title="Stock Research Agents", page_icon="📈", layout="wide")
st.markdown("""
<style>
  :root { color-scheme: dark; }
  .stApp { background: #0b171a; color: #edf4ef; }
  .block-container { max-width: 1200px; padding-top: 2.5rem; }
  h1, h2, h3 { letter-spacing: -.035em; }
  h1 { font-size: clamp(2.1rem, 4vw, 3.3rem) !important; }
  .eyebrow { color: #b7e982; font-size: .78rem; font-weight: 800; letter-spacing: .13em; }
  .muted { color: #a9bdba; font-size: .95rem; }
  .tag { display: inline-block; border: 1px solid #64876c; border-radius: 99px; padding: .25rem .65rem; color: #c5eda4; font-size: .85rem; font-weight: 700; }
  [data-testid="stMetric"] { background: #14262a; border: 1px solid #355357; border-radius: 12px; padding: 1rem; }
  [data-testid="stVerticalBlockBorderWrapper"] { background: #14262a; border-color: #355357 !important; }
  [data-testid="stButton"] button[kind="primary"] { background: #b7e982; color: #13251a; font-weight: 750; border: 0; }
  a { color: #b7e982 !important; }
</style>
""", unsafe_allow_html=True)


def secret(name: str) -> str:
    try:
        return str(st.secrets.get(name) or os.getenv(name) or "")
    except FileNotFoundError:
        return os.getenv(name, "")


@st.cache_data(ttl=900, show_spinner=False)
def load_report(symbol: str, news_key: str) -> dict:
    market = market_data(symbol)
    fundamentals, warnings = fundamental_data(market)
    try:
        articles = news_data(fundamentals["name"], market["symbol"], news_key)
    except Exception as exc:
        articles = []
        # Do not print request URLs or exceptions: NewsData's key is a URL parameter.
        warnings.append("Recent news could not be loaded. Check the NewsData secret and its API allowance.")
    market.pop("ticker", None)
    result = evaluate(market, fundamentals, articles, warnings)
    return {"market": market, "fundamentals": fundamentals, "articles": articles, **result}


def fmt(value: float | None, decimals: int = 1) -> str:
    return "—" if value is None else f"{value:,.{decimals}f}"


def percent(value: float | None) -> str:
    return "—" if value is None else f"{value:+.1f}%"


st.markdown('<div class="eyebrow">MULTI-AGENT EQUITY RESEARCH</div>', unsafe_allow_html=True)
st.title("One stock. Three perspectives.")
st.markdown('<p class="muted">Search a ticker for market signals, company fundamentals, recent headlines, and a combined verdict.</p>', unsafe_allow_html=True)

with st.form("ticker_search"):
    search_col, button_col = st.columns([5, 1.4], vertical_alignment="bottom")
    with search_col:
        typed = st.text_input("Stock ticker", value=st.session_state.get("typed", "TCS"), placeholder="TCS, RELIANCE, AAPL, MSFT…")
    with button_col:
        submitted = st.form_submit_button("Analyze stock", type="primary", use_container_width=True)
st.caption("Bare tickers try NSE first. Use an exchange suffix such as .NS or .BO when needed.")
if submitted:
    st.session_state["typed"] = typed.strip().upper()
    st.session_state["search"] = st.session_state["typed"]
if "search" not in st.session_state:
    st.info("Enter a ticker and select **Analyze stock** to begin.")
    st.stop()

with st.spinner("Gathering prices, fundamentals, and headlines…"):
    try:
        report = load_report(st.session_state["search"], secret("NEWSDATA_API_KEY"))
    except ValueError as exc:
        st.error(str(exc))
        st.stop()
    except Exception:
        st.error("The data providers could not complete this lookup. Try a full exchange symbol or retry later.")
        st.stop()

m = report["market"]
f = report["fundamentals"]
st.divider()
header, last_price = st.columns([3, 1], vertical_alignment="bottom")
with header:
    st.markdown('<div class="eyebrow">STOCK SNAPSHOT</div>', unsafe_allow_html=True)
    st.header(f["name"])
    st.markdown(f'<span class="tag">{m["symbol"]}</span>', unsafe_allow_html=True)
    if f["sector"]:
        st.caption(f["sector"])
with last_price:
    st.metric("Latest available close", f'{m["currency"]} {fmt(m["price"], 2)}')
    st.caption(f'Price date: {m["last_price_date"]}')

chart_col, indicator_col = st.columns([1.5, 1], gap="large")
with chart_col:
    st.subheader("Price trend · 1 year")
    chart = pd.DataFrame(m["chart"], columns=["date", "close"]).set_index("date")
    st.line_chart(chart, color="#b7e982", height=260)
with indicator_col:
    st.subheader("Market indicators")
    a, b = st.columns(2)
    a.metric("6-month return", percent(m["return6m"]))
    b.metric("12-month return", percent(m["return12m"]))
    a.metric("50-day average", fmt(m["sma50"], 2))
    b.metric("200-day average", fmt(m["sma200"], 2))
    st.metric("Annualized volatility", percent(m["volatility"]))

st.divider()
st.markdown('<div class="eyebrow">AGENT VIEWS</div>', unsafe_allow_html=True)
st.subheader("Separate signals, shared decision")
agent_cols = st.columns(3, gap="medium")
for column, (name, view) in zip(agent_cols, report["agents"].items()):
    with column:
        with st.container(border=True):
            st.markdown(f"#### {name} Agent")
            st.markdown(f"**View: {view['label']}** · Score {view['score']}")
            for reason in view["reasons"]:
                st.write("•", reason)

st.subheader("Fundamental data")
fundamental_metrics = (
    ("P/E", fmt(f["pe"])),
    ("Price / book", fmt(f["pb"])),
    ("ROE", percent(f["roe"])),
    ("Debt / equity", f'{fmt(f["debt_equity"], 2)}x' if f["debt_equity"] is not None else "—"),
    ("ROCE", percent(f["roce"])),
    ("Market cap", f["market_cap"] or "—"),
)
for start in (0, 3):
    for column, (label, value) in zip(st.columns(3), fundamental_metrics[start:start + 3]):
        column.metric(label, value)
st.caption(f'Source: {f["source"]}. Missing ratios are excluded from scoring.')
if f["url"]:
    st.link_button("View company on Screener", f["url"])

st.subheader("Recent headlines")
if report["articles"]:
    for article in report["articles"]:
        st.write(article["title"])
        st.caption(f'{article["source"]} · {article["date"] or "Date unavailable"}')
        st.link_button("Read article", article["link"])
else:
    st.info("No relevant recent headlines are available. The News Agent is excluded from the combined score.")

st.divider()
verdict = report["verdict"]
st.markdown('<div class="eyebrow">FINAL AGENT VERDICT</div>', unsafe_allow_html=True)
st.header(verdict["label"])
st.write(verdict["summary"])
st.caption(verdict["coverage"] + " Rule-based synthesis; no language model was used.")
st.markdown("**What to watch**")
for risk in verdict["risks"]:
    st.write("•", risk)
for warning in report["warnings"]:
    st.warning(warning)
st.caption(f'Checked {datetime.fromisoformat(report["checked_at"]).astimezone():%d %b %Y, %H:%M %Z}. Research aid only; verify figures and filings before investing.')
