# Stock Research Agents for Streamlit

A single-ticker research page adapted from `STUDENT_HEDGE_FUND_AGENT_V4.ipynb`.
It combines Quant, Fundamental, and News agent views into an explicit,
rule-based watch/avoid verdict. It does not call a generative AI model.

## Run locally

1. Install Python 3.12 and run `pip install -r requirements.txt`.
2. Copy `.streamlit/secrets.example.toml` to `.streamlit/secrets.toml` and replace the example value with your NewsData.io API key. Never commit `secrets.toml`.
3. Run `streamlit run app.py`.

## Deploy on Streamlit Community Cloud

1. Put this folder's contents in a GitHub repository you administer.
2. At [share.streamlit.io](https://share.streamlit.io/), select **Create app**, the repository and branch, and `app.py` as the entrypoint.
3. In **Advanced settings**, select Python 3.12 and add this secret:

   ```toml
   NEWSDATA_API_KEY = "your-actual-key"
   ```

4. Deploy. The dependency installer reads `requirements.txt`.

For bare symbols the app tries the NSE `.NS` ticker first, then the plain
symbol. Yahoo Finance supplies price history and company profile data;
Screener's public company page supplements Indian ratios; NewsData.io supplies
latest headlines. Yahoo and Screener do not use API keys in this version.
Availability and rate limits can vary. Missing sources are disclosed and excluded
from the combined verdict.
